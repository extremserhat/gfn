# OAuth general information

| service    | callback URL (after the server URL) |
| ---------- | ----------------------------------- |
| facebook   | `/auth/facebook/callback`           |
| twitter    | `/auth/twitter/callback`            |
| github     | `/auth/github/callback`             |
| gitlab     | `/auth/gitlab/callback`             |
| mattermost | `/auth/mattermost/callback`         |
| dropbox    | `/auth/dropbox/callback`            |
| google     | `/auth/google/callback`             |
| saml       | `/auth/saml/callback`               |
