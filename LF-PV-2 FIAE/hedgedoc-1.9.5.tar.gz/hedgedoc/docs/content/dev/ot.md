# Operational Transformation

From 0.3.2, we started supporting operational transformation.
It makes concurrent editing safe and will not break up other users' operations.
Additionally, now can show other clients' selections.

See more at [https://operational-transformation.github.io/](https://operational-transformation.github.io/)

And even more in this 2010 article series:

- <https://drive.googleblog.com/2010/09/whats-different-about-new-google-docs_21.html>
- <https://drive.googleblog.com/2010/09/whats-different-about-new-google-docs_22.html>
- <https://drive.googleblog.com/2010/09/whats-different-about-new-google-docs.html>
