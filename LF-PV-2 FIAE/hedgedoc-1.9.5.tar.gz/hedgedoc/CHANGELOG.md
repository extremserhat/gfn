# CHANGELOG

Please refer to the release notes published under 
[`public/docs/release-notes.md`](public/docs/release-notes.md).

These are also available on each HedgeDoc instance under
<https://[domain-name]/release-notes>
