module.exports = {
  root: true,
  extends: ['standard'],
  env: {
    node: true
  },
  rules: {}
}
